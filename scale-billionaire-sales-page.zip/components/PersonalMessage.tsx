
import React from 'react';

export const PersonalMessage: React.FC = () => {
  return (
    <section className="bg-white p-8 md:p-12 rounded-3xl border border-slate-200 shadow-xl -mt-20 relative z-20">
      <div className="flex items-center gap-4 mb-6">
        <img 
          src="https://picsum.photos/seed/gon/100/100" 
          alt="Gon CFO" 
          className="w-16 h-16 rounded-full border-2 border-orange-500 p-1"
        />
        <div>
          <h3 className="font-bold text-lg">Gon (CFO พันล้าน)</h3>
          <p className="text-slate-500 text-sm">เขียนด้วยตัวเองทุกตัวอักษร</p>
        </div>
      </div>
      
      <p className="text-lg text-slate-700 leading-relaxed space-y-4">
        <strong>หยุดอ่านตรงนี้แป๊บนึงนะฮะ...</strong> อันนี้กอนตั้งใจสร้าง content นี้ให้คุณได้ลองเปลี่ยนแปลงตัวเองจริงๆ ไม่ได้ให้ AI เขียนมาให้คุณอ่านเล่นๆ 
        ที่ต้องบอกแบบนี้ เพราะเรื่องเงินร้อยล้านมันเรื่องใหญ่ ผมอยากคุยกับคุณแบบ "คนต่อคน" จริงๆ 
      </p>
      
      <p className="text-lg text-slate-700 leading-relaxed mt-4">
        เพราะความรู้สึกของคนทำธุรกิจที่แบกความรับผิดชอบไว้บนไหล่... AI มันไม่เข้าใจหรอกครับ แต่ผมเข้าใจดี
      </p>
    </section>
  );
};
