
import React, { useState } from 'react';
import { getBusinessAdvice } from '../services/geminiService';

export const BusinessHealthCheck: React.FC = () => {
  const [problem, setProblem] = useState('');
  const [advice, setAdvice] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const handleCheck = async () => {
    if (!problem.trim()) return;
    setLoading(true);
    const result = await getBusinessAdvice(problem);
    setAdvice(result);
    setLoading(false);
  };

  return (
    <section className="bg-blue-50 p-8 rounded-3xl border border-blue-100">
      <div className="flex flex-col md:flex-row gap-8 items-start">
        <div className="w-full md:w-1/2 space-y-4">
          <div className="inline-block bg-blue-600 text-white px-3 py-1 rounded-full text-xs font-bold uppercase">
            AI Business Health Check
          </div>
          <h2 className="text-2xl font-bold">คุยกับ "กอน AI" เบื้องต้น</h2>
          <p className="text-slate-600">
            ลองพิมพ์ปัญหาการเงินที่คุณเจออยู่ตอนนี้ แล้วให้กอนช่วยวิเคราะห์ดูครับ ว่าทำไมคุณถึงต้องการระบบ Cashflow
          </p>
          <textarea 
            className="w-full p-4 rounded-xl border border-blue-200 h-32 focus:ring-2 focus:ring-blue-500 focus:outline-none"
            placeholder="เช่น ยอดขายดีแต่เงินไม่เคยเหลือเลย หรือสต็อกเยอะจนหมุนเงินไม่ทัน..."
            value={problem}
            onChange={(e) => setProblem(e.target.value)}
          />
          <button 
            onClick={handleCheck}
            disabled={loading || !problem}
            className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-xl disabled:opacity-50 transition-all flex items-center gap-2"
          >
            {loading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                กอนกำลังวิเคราะห์...
              </>
            ) : "ให้กอนวิเคราะห์ (ฟรี)"}
          </button>
        </div>
        
        <div className="w-full md:w-1/2 min-h-[200px] flex items-center justify-center border-2 border-dashed border-blue-200 rounded-2xl bg-white/50 p-6">
          {advice ? (
            <div className="space-y-4 text-slate-800 animate-in fade-in slide-in-from-right-4 duration-500">
              <div>
                <span className="font-bold text-blue-800 block mb-1">🔍 วิเคราะห์รูรั่ว:</span>
                <p>{advice.analysis}</p>
              </div>
              <div className="bg-white p-4 rounded-xl border border-blue-100 shadow-sm">
                <span className="font-bold text-orange-600 block mb-1">💡 คำแนะนำจาก CFO:</span>
                <p className="italic">"{advice.advice}"</p>
              </div>
              <div className="text-sm text-slate-600">
                <span className="font-bold text-blue-800">🚀 ทำไม Template ถึงจำเป็น:</span> {advice.whyTemplate}
              </div>
            </div>
          ) : (
            <div className="text-center text-slate-400">
              <svg className="w-12 h-12 mx-auto mb-2 opacity-20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"></path>
              </svg>
              <p>พิมพ์ปัญหาของคุณ แล้วกอนจะช่วยตอบครับ</p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
