
import React from 'react';
import { PartDetails } from '../types';

const PARTS: PartDetails[] = [
  {
    icon: "📖",
    title: "Part 1: การจัดการจังหวะเงิน (OPM Strategy)",
    description: "วิธีใช้เครดิตเป็นอาวุธ เก็บเงินลูกค้าให้ไว จ่าย Supplier ให้ช้าลง เพื่อให้มี 'เงินฟรี' มาหมุนธุรกิจ"
  },
  {
    icon: "🎯",
    title: "Part 2: การจัดการสต็อกไม่ให้เงินจม",
    description: "วิธีรีดไขมันส่วนเกินในโกดัง ของชิ้นไหนวางนิ่งเกิน 60 วัน... มันคือขยะที่ดูดเงินคุณอยู่ ผมจะสอนวิธีดูให้ออก"
  },
  {
    icon: "💪",
    title: "Part 3: Cashflow Dashboard (ของจริง)",
    description: "ไฟล์ที่ผมใช้วางโครงสร้างให้บริษัทระดับพันล้าน แค่กรอกตัวเลข คุณจะเห็นทันทีว่าเดือนหน้าจะเหลือเงินเท่าไหร่"
  }
];

interface ProductOfferProps {
  remainingSlots: number;
  openCheckout: () => void;
}

export const ProductOffer: React.FC<ProductOfferProps> = ({ remainingSlots, openCheckout }) => {
  return (
    <section className="bg-white rounded-3xl overflow-hidden shadow-2xl border border-slate-200">
      <div className="bg-slate-900 text-white p-8 md:p-12">
        <h2 className="text-3xl font-bold mb-8 text-center">สิ่งที่คุณจะได้รับใน Template Cashflow (+ คู่มือฉบับย่อ)</h2>
        <div className="grid md:grid-cols-3 gap-8">
          {PARTS.map((part, idx) => (
            <div key={idx} className="space-y-4">
              <div className="text-4xl">{part.icon}</div>
              <h3 className="text-xl font-bold">{part.title}</h3>
              <p className="text-slate-400 leading-relaxed">{part.description}</p>
            </div>
          ))}
        </div>
      </div>
      
      <div className="p-8 md:p-12 text-center">
        <div className="mb-8">
          <h3 className="text-2xl font-bold mb-4">ทำไมต้องขายแค่ 40 บาท?</h3>
          <p className="text-slate-600 max-w-2xl mx-auto">
            มีคนถามเยอะมากว่า "กอน... ให้ที่ปรึกษาการเงินระดับ CFO มาทำไฟล์ให้ ขายแค่ 40 บาทเนี่ยนะ?" 
          </p>
          <p className="text-slate-700 mt-4 font-medium italic">
            คำตอบคือ: 1. ผมอยากให้คุณเห็นความเทพของระบบอัตโนมัติ 2. ผมอยากช่วย SME ไทยติดกับดัก 100 ล้าน ให้เข้าถึงเครื่องมือระดับโลกในราคาถูกกว่าค่าน้ำแข็งถังเดียวครับ ฮ่าๆ
          </p>
        </div>
        
        <div className="bg-slate-50 p-8 rounded-2xl border-2 border-dashed border-slate-300 relative">
          <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-red-600 text-white px-4 py-1 rounded-full text-sm font-bold animate-pulse">
             {remainingSlots}/100 slots left
          </div>
          
          <h4 className="text-xl font-bold mb-2">เริ่มคุมเกมการเงินวันนี้</h4>
          <p className="text-slate-500 mb-6 line-through">ราคาปกติ 1,500 บาท</p>
          
          <div className="text-6xl font-black text-slate-900 mb-8">
            40 บาท
          </div>
          
          <button 
            onClick={openCheckout}
            className="bg-orange-600 hover:bg-orange-500 text-white text-2xl font-bold py-5 px-16 rounded-2xl shadow-xl transition-all transform hover:scale-105 active:scale-95"
          >
            สั่งซื้อเลย - รับไฟล์ทันที
          </button>
        </div>
      </div>
    </section>
  );
};
