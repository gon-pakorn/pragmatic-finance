
import React from 'react';
import { FAQItem } from '../types';

const FAQS: FAQItem[] = [
  {
    question: "ไม่มีพื้นฐานบัญชีเลยใช้ได้มั้ย?",
    answer: "ได้แน่นอนครับ! ผมออกแบบมาให้ 'เจ้าของธุรกิจ' ดู ไม่ใช่ให้ 'นักบัญชี' ดู ภาษาที่ใช้คือภาษาคนทำธุรกิจที่อยากเห็นกำไรครับ"
  },
  {
    question: "จ่ายเงินแล้วได้ของยังไง?",
    answer: "ทันทีที่คุณชำระเงิน ระบบ DDS (Digital Delivery System) ของผมจะส่งลิงก์ดาวน์โหลดให้คุณทาง Email ทันที ไม่ต้องรอผมตื่นมาส่งให้ฮะ"
  },
  {
    question: "ถ้าใช้ไม่เป็นทำไง?",
    answer: "ในไฟล์มีคำอธิบายสั้นๆ ง่ายๆ ให้ครับ หรือถ้าสงสัยจริงๆ ทักมาถามในเพจได้ กอนพิมตอบเองเสมอครับ"
  }
];

export const FAQ: React.FC = () => {
  return (
    <section>
      <h2 className="text-3xl font-bold text-center mb-12">คำถามที่ถามบ่อย</h2>
      <div className="max-w-2xl mx-auto space-y-4">
        {FAQS.map((faq, idx) => (
          <div key={idx} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <h3 className="font-bold text-lg mb-2 text-slate-900">{faq.question}</h3>
            <p className="text-slate-600">{faq.answer}</p>
          </div>
        ))}
      </div>
    </section>
  );
};
