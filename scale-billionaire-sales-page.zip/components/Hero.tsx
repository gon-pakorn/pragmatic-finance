
import React from 'react';

interface HeroProps {
  openCheckout: () => void;
}

export const Hero: React.FC<HeroProps> = ({ openCheckout }) => {
  return (
    <header className="bg-billionaire text-white pt-24 pb-32 px-4 text-center relative overflow-hidden">
      <div className="absolute inset-0 opacity-20 pointer-events-none">
        <div className="absolute top-10 left-10 w-40 h-40 border border-white/20 rounded-full animate-pulse"></div>
        <div className="absolute bottom-10 right-10 w-60 h-60 border border-white/10 rounded-full animate-bounce"></div>
      </div>
      
      <div className="max-w-4xl mx-auto relative z-10">
        <div className="inline-block bg-orange-500/20 text-orange-400 px-4 py-1 rounded-full text-sm font-semibold mb-6 tracking-wide">
          🚀 CFO MILLIONAIRE STRATEGY
        </div>
        
        <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
          Light-Scale Billionaire:<br/>
          <span className="gradient-text">สูตรลับปั้นธุรกิจ 2,500 ล้าน</span>
        </h1>
        
        <p className="text-xl md:text-2xl text-slate-300 mb-4 max-w-2xl mx-auto">
          เปลี่ยนจากเจ้าของธุรกิจที่ "งานยุ่งจนหัวหมุน"
        </p>
        <p className="text-2xl md:text-3xl font-bold text-white mb-6">
          เป็นเจ้าของระบบที่ "ตัวเบาหวิวแต่กำไรหนักมาก"
        </p>
        
        <p className="text-lg text-slate-400 mb-10 italic">
          (แม้ว่าตอนนี้คุณจะไม่มีพื้นฐานการเงิน หรือไม่รู้ว่าเงินในบริษัทหายไปไหนหมด)
        </p>
        
        <div className="space-y-4">
          <button 
            onClick={openCheckout}
            className="bg-orange-600 hover:bg-orange-500 text-white text-xl font-bold py-4 px-10 rounded-2xl shadow-[0_0_30px_rgba(234,88,12,0.4)] transition-all transform hover:scale-105 active:scale-95"
          >
            เริ่มคุมเกมการเงินทันที - 40 บาท
          </button>
          
          <div className="flex flex-col md:flex-row justify-center items-center gap-4 text-slate-400 text-sm mt-6">
            <span className="flex items-center gap-1">
              <svg className="w-5 h-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>
              รับ Template ไปใช้ได้ทันที
            </span>
            <span className="flex items-center gap-1">
              <svg className="w-5 h-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>
              ระบบส่งออโต้ 24 ชม. ไม่ต้องรอแอดมิน
            </span>
          </div>
        </div>
      </div>
    </header>
  );
};
