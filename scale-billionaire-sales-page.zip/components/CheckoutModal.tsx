
import React, { useState } from 'react';

interface CheckoutModalProps {
  onClose: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({ onClose }) => {
  const [step, setStep] = useState<'details' | 'success'>('details');
  const [email, setEmail] = useState('');

  const handlePay = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setStep('success');
  };

  return (
    <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden relative">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-600"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
        </button>
        
        {step === 'details' ? (
          <div className="p-8">
            <h3 className="text-2xl font-bold mb-6">เริ่มสเกลธุรกิจของคุณ</h3>
            <form onSubmit={handlePay} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Email สำหรับรับไฟล์</label>
                <input 
                  type="email" 
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full p-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-orange-500 focus:outline-none"
                  placeholder="name@company.com"
                />
              </div>
              
              <div className="bg-slate-50 p-4 rounded-xl space-y-2">
                <div className="flex justify-between font-medium">
                  <span>Cashflow Dashboard Template</span>
                  <span>40.-</span>
                </div>
                <div className="flex justify-between text-slate-500 text-sm">
                  <span>Asset-Light Scaling Guide</span>
                  <span className="text-green-600 font-bold">ฟรี!</span>
                </div>
                <div className="border-t pt-2 flex justify-between font-bold text-lg text-orange-600">
                  <span>รวมทั้งสิ้น</span>
                  <span>40.-</span>
                </div>
              </div>
              
              <button 
                type="submit"
                className="w-full bg-slate-900 text-white font-bold py-4 rounded-xl hover:bg-slate-800 transition-all shadow-lg shadow-slate-200"
              >
                ชำระเงิน 40 บาท
              </button>
              <p className="text-xs text-center text-slate-400 italic">
                ชำระเงินผ่านระบบอัตโนมัติ ปลอดภัย ได้รับไฟล์ทันที
              </p>
            </form>
          </div>
        ) : (
          <div className="p-8 text-center space-y-6">
            <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto">
              <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"></path></svg>
            </div>
            <h3 className="text-2xl font-bold">ขอบคุณครับ!</h3>
            <p className="text-slate-600">
              กอนส่งไฟล์ Template ไปให้ที่อีเมล <br/>
              <span className="font-bold text-slate-900">{email}</span> แล้วนะครับ 
              ลองเปิดดูได้เลย!
            </p>
            <button 
              onClick={onClose}
              className="w-full bg-slate-900 text-white font-bold py-3 rounded-xl"
            >
              ตกลง
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
