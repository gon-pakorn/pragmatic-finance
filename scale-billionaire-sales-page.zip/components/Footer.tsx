
import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-900 text-slate-500 py-12 px-4 border-t border-slate-800">
      <div className="max-w-4xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
        <div>
          <div className="text-xl font-bold text-white mb-1">GON CFO</div>
          <p className="text-sm">© 2026 Light-Scale Billionaire. All rights reserved.</p>
        </div>
        
        <div className="flex gap-8 text-sm">
          <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
          <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          <a href="#" className="hover:text-white transition-colors">Contact Support</a>
        </div>
      </div>
      
      <div className="max-w-4xl mx-auto mt-8 text-xs text-center border-t border-slate-800 pt-8 opacity-50">
        การลงทุนและผลลัพธ์ทางธุรกิจขึ้นอยู่กับการนำระบบไปปรับใช้รายบุคคล ผลลัพธ์ 2,500 ล้าน เป็นประสบการณ์ส่วนตัวของคุณกอนในฐานะ CFO มืออาชีพ
      </div>
    </footer>
  );
};
