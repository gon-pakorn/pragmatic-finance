
import React from 'react';
import { PainPoint } from '../types';

const PAIN_POINTS: PainPoint[] = [
  {
    emoji: "😰",
    title: "ยอดขายเยอะแต่เงินหาย",
    description: "ยอดขายเข้าทุกวัน ดูในบัญชีเหมือนจะเยอะ แต่พอถึงสิ้นเดือน... ค่า Supplier มา ค่าเช่ารออยู่ สรุปเหลือเงินให้ตัวเองนิดเดียว"
  },
  {
    emoji: "😔",
    title: "รวยแต่หมุนเงินไม่ทัน",
    description: "ขับรถดี มีเทส แต่ตกดึกต้องมานั่งเครียดเรื่องกระแสเงินสด เพราะไม่รู้ว่า 'รูรั่ว' จริงๆ อยู่ตรงไหน"
  },
  {
    emoji: "😞",
    title: "อยากสเกลแต่กลัวล้น",
    description: "อยากสเกลธุรกิจใจจะขาด แต่กลัวว่าถ้าโตกว่านี้ งานจะล้นจนไม่มีเวลาใช้ชีวิต"
  }
];

export const PainPoints: React.FC = () => {
  return (
    <section>
      <h2 className="text-3xl font-bold text-center mb-12">คุณเคยรู้สึกแบบนี้มั้ย?</h2>
      <div className="grid md:grid-cols-3 gap-8">
        {PAIN_POINTS.map((item, idx) => (
          <div key={idx} className="bg-slate-50 p-6 rounded-2xl border border-slate-200 hover:border-orange-200 transition-colors">
            <div className="text-5xl mb-4">{item.emoji}</div>
            <h3 className="text-xl font-bold mb-3">{item.title}</h3>
            <p className="text-slate-600">{item.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
};
