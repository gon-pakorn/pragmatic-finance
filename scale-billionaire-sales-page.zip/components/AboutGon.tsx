
import React from 'react';

export const AboutGon: React.FC = () => {
  return (
    <section className="flex flex-col md:flex-row items-center gap-12">
      <div className="w-full md:w-1/2">
        <div className="relative">
          <img 
            src="https://picsum.photos/seed/cfo/600/600" 
            alt="Gon CFO" 
            className="rounded-3xl shadow-2xl grayscale hover:grayscale-0 transition-all duration-500"
          />
          <div className="absolute -bottom-6 -right-6 bg-orange-600 text-white p-6 rounded-2xl shadow-xl">
            <div className="text-3xl font-bold">2,500M+</div>
            <div className="text-sm opacity-80">Portfolio Value Managed</div>
          </div>
        </div>
      </div>
      
      <div className="w-full md:w-1/2 space-y-6">
        <h2 className="text-3xl font-bold">ผมเข้าใจ... เพราะผมเคยพาบริษัทไปถึงจุดนั้นมาแล้ว</h2>
        <p className="text-lg text-slate-600 italic">"สวัสดีครับ ผมชื่อกอน ปัจจุบันเป็น CFO ที่ดูแลบริษัทตั้งแต่หลักร้อยล้านจนไปแตะ 2,500 ล้านภายใน 5 ปี"</p>
        
        <p className="text-slate-700 leading-relaxed">
          แต่ก่อนที่จะไปถึงจุดนั้น ผมก็เคยเห็นเจ้าของธุรกิจที่ "รวยแต่..." (รวยแต่เครียด) มาเยอะมากครับ เงินจมในสต็อกบ้าง โดน Supplier บีบบ้าง จนผมค้นพบว่า...
        </p>
        
        <div className="bg-orange-50 border-l-4 border-orange-500 p-4 font-bold text-orange-900">
          การจะโตแบบยั่งยืน คุณต้องทำธุรกิจแบบ Asset-Light (ตัวเบา)
        </div>
        
        <p className="text-slate-700 leading-relaxed">
          เราไม่จำเป็นต้องเป็นเจ้าของทุกอย่าง เราแค่ต้องเป็นเจ้าของ "ระบบ" ที่ฉลาดที่สุด
        </p>
      </div>
    </section>
  );
};
