
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getBusinessAdvice(problem: string) {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `ในฐานะคุณกอน (Gon CFO) ผู้เชี่ยวชาญด้านการเงินระดับพันล้าน (Asset-Light strategy) ช่วยวิเคราะห์ปัญหาธุรกิจนี้และให้คำแนะนำเบื้องต้นสั้นๆ พร้อมสรุปว่าทำไม Template Cashflow ของกอนจะช่วยเขาได้: "${problem}"`,
    config: {
      temperature: 0.8,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          analysis: { type: Type.STRING, description: "Analysis of the user's problem" },
          advice: { type: Type.STRING, description: "Gon's quick CFO advice" },
          whyTemplate: { type: Type.STRING, description: "Why the template is the solution" }
        },
        required: ["analysis", "advice", "whyTemplate"]
      }
    }
  });

  try {
    return JSON.parse(response.text.trim());
  } catch (e) {
    console.error("Failed to parse AI response", e);
    return null;
  }
}
